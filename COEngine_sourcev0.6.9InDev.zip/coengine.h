//Engine .h file

#pragma once

#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

//Config
static string version = "0.6.9 INDEV";

static int fileVersion = 1;

using namespace std;

int coengine()
{

	void checkConfig();
	{
		if (fileVersion == NULL) {
			fileVersion = 1;

			cout << "fileVersion in coengine.h is not givin or invalid, setting it to 1. [*INFO*]" << endl;

		}

		if (version == "") {
			version = "0.6.9 INDEV";

			cout << "version on coengine.h is not givin or invalid, setting it to default 0.6.8 INDEV. [*INFO*]" << endl;

		}
	}

	return 0;


}
