void CreateLog(const char* message);

void IniLog(const char* logmsg) {
	CreateLog(logmsg);
}

